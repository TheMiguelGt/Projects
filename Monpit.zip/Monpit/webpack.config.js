const path = require('path');
const htmlwebpackplugin = require('html-webpack-plugin');
const minicssextractplugin = require('mini-css-extract-plugin');

const devMode = process.env.NODE_ENV !== 'production';
console.log(devMode)


module.exports ={

    entry: './frontend/app.js',
    output:{
        path:path.join(__dirname, 'backend/public'),
        filename: 'js/bundle.js'
    },
    mode:'development',
    module:{
        rules:[{
            test: /\.css/,
            use:[
                devMode ? 'style-loader':minicssextractplugin.loader,
                'css-loader'
            ]
        }
        ]
    },
    plugins:[
        new htmlwebpackplugin({
            template: './frontend/index.html',
            minify:{
                collapseWhitespace: true,
                removeComments: true,
                removeRedundantAttributes:true,
                removeScriptTypeAttributes: true,
                removeScriptLinkAttributes: true,
                useShortDoctype:true

            }
        }),
        new minicssextractplugin({
            filename:'css/bundle.css'
        })
    ],
    devtool:'source-map'
};