const { Router } = require('express');
const router = Router();

const Alumno = require('../models/Alumno');

router.get('/',async(req, res)=> {
    const books = await Alumno.find(); //consulta de alumnos
    res.json(books);
});

router.post('/', async (req, res) => { //crear 
    const {nombre,apellido,correo,contrasena,codclase}=req.body; //extraer
    const newAlumno = new Alumno({nombre,apellido,correo,contrasena,codclase})
    await newAlumno.save();
    res.json({message: 'Alumno creado'});
});

//router.delete('/:id',async (req,res) => { //metodo para eliminar
  //  console.log(req.params.id)    //por el id
    //res.send('deleting'); 
    //const alumno = await Alumno.findByIdAndDelete(req.params.id); //busca por el id

//});


module.exports = router;