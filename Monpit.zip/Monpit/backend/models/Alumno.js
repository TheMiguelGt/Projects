const { Schema, model } = require('mongoose');

const AlumnoSchema = new Schema({
    nombre:{ type:String,required: true},
    apellido:{ type:String,required: true},
    correo:{ type:String,required:true},
    contrasena:{ type:String,required:true},
    codclase:{ type:String,required:true},
    imagePath: { type:String}
})

module.exports = model('Alumno',AlumnoSchema);